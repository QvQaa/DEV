"""
Benchmarks in this directory should depend only on tslibs, tseries.offsets,
and to_offset.

i.e. any code changes that do not touch those files should not need to
run these benchmarks.
"""
